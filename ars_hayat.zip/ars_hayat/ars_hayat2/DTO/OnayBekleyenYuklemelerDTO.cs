﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ars_hayat2.DTO
{
    public class OnayBekleyenYuklemelerDTO
    {
        public int NakliyeBelgesi { get; set; }
        public DateTime PlanlamaTarihi { get; set; }
        public string UretimYeri { get; set; }
        public string Nakliyeci { get; set; }
        public string Musteriler { get; set; }
        public string SevkYeri { get; set; }
        public string AciklamaSM { get; set; }
        public int ToplamTonaj { get; set; }
        public string AracTipi { get; set; }
        public int YuklemeYeriId { get; set; }
        public int NakliyeciId { get; set; }
        public int YuklemeNoktasiId { get; set; }

    }
}
