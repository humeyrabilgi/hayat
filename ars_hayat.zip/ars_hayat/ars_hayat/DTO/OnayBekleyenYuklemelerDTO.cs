﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ars_hayat.DTO
{
    public class OnayBekleyenYuklemelerDTO
    {
        public int NakliyeBelgesi { get; set; }
        public DateTime PlanlamaTarihi { get; set; }
        public string NakliyeciAdi { get; set; }
        public string AciklamaSM { get; set; }
        public float ToplamTonaj { get; set; }
        public string AracTipiId { get; set; }
        public int YuklemeYeriId { get; set; }
        public int YuklemeNoktasiId { get; set; }
        public int Id { get; set; }
        public string YNAdi { get; set; }
        public string Musteriler { get; set; }
        public string UretimYeriAdi { get; set; }
        public int UretimyeriKodu { get; set; }
        public int SehirId { get; set; }
        public int YuklemeStatus{ get; set;}
        public string TeslimatYerleri { get; set; }
       

    }
}
