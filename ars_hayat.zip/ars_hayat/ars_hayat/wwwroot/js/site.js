﻿var i;
var data = null;
var id;
var selected_row_id = null;
var dataGrid2 = null;
var dropdown = document.getElementsByName("leftmenu");
//Left Menu
var dropdown = document.getElementsByName("leftmenu");
for (i = 0; i < dropdown.length; i++) {
    dropdown[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
            dropdownContent.style.display = "none";
        } else {
            dropdownContent.style.display = "block";
        }
    });
}
//Function for login
$(document).ready(function () {
    $('#a').click(function () {     
        $.ajax({
            url: "/token/new",
            method: "POST",            
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({
                userName: $('.form-control1').val(),
                password: $('.form-control2').val()
            })


    });
    });
    //Function For Grid1
    function logEvent(eventName) {
        var logList = $("#events ul"),
            newItem = $("<li>", { text: eventName });

        logList.prepend(newItem);
    }
    var orders = new DevExpress.data.CustomStore({
        key:"id",
        load: function (loadOptions) {
            var deferred = $.Deferred(),
                args = {};
    
            if (loadOptions.sort) {
                args.orderby = loadOptions.sort[0].selector;
                if (loadOptions.sort[0].desc)
                    args.orderby += " desc";
            }
    
            args.skip = loadOptions.skip || 0;
            args.take = loadOptions.take || 12;
    
            $.ajax({
                url: "/Home/getGridDatas",
                dataType: "json",
                data: args,
                success: function (result) {         
                    deferred.resolve(result.items, { totalCount:result.total_count });
                },
                error: function() {
                    deferred.reject("Data Loading Error");
                },
                timeout: 5000
            });
    
            return deferred.promise();
        },
        update: function (key, values)
        {
            return $.ajax({
                url: "Home/Update1",
                contentType: "application/json; charset=utf-8",
                method: "PUT",
                data: JSON.stringify(values),
                dataType: "json"
            });
        },
        remove: function (key, values) {
           
            return $.ajax({
                url: "Home/Remove",
                
                method: "DELETE",
                data: values,
                
            });
        },
        insert: function (values) {
            return $.ajax({
                url: "Home/Insert",
                contentType: "application/json; charset=utf-8",
                method: "POST",
                data: JSON.stringify(values),
                dataType: "json"
            });
        },
        byKey: function (key) {
            return $.get('http://sampleservices.devexpress.com/api/Categories/' + key.toString());
        }
    });   
    var aracTipi = new DevExpress.data.CustomStore({
        load: function (loadOptions) {
            var deferred = $.Deferred(),
                args = {};

            if (loadOptions.sort) {
                args.orderby = loadOptions.sort[0].selector;
                if (loadOptions.sort[0].desc)
                    args.orderby += " desc";
            }

            args.skip = loadOptions.skip || 0;
            args.take = loadOptions.take || 12;

            $.ajax({
                url: "/Home/aracTipiDropDown",
                dataType: "json",
                data: args,
                success: function (result) {             
                    deferred.resolve(result.items, { totalCount: result.total_count });
                },
                error: function () {
                    deferred.reject("Data Loading Error");
                },
                timeout: 5000
            });

            return deferred.promise();
        }
    });
    var yuklemeNoktasi = new DevExpress.data.CustomStore({
        load: function (loadOptions) {
            var deferred = $.Deferred(),
                args = {};

            if (loadOptions.sort) {
                args.orderby = loadOptions.sort[0].selector;
                if (loadOptions.sort[0].desc)
                    args.orderby += " desc";
            }

            args.skip = loadOptions.skip || 0;
            args.take = loadOptions.take || 12;

            $.ajax({
                url: "/Home/yuklemeNoktasiDropDown",
                dataType: "json",
                data: args,
                success: function (result) {                 
                    deferred.resolve(result.items, { totalCount: result.total_count });
                },
                error: function () {
                    deferred.reject("Data Loading Error");
                },
                timeout: 5000
            });

            return deferred.promise();
        }
    });  
    var uretimyeri = new DevExpress.data.CustomStore({
        load: function (loadOptions) {
            var deferred = $.Deferred(),
                args = {};

            if (loadOptions.sort) {
                args.orderby = loadOptions.sort[0].selector;
                if (loadOptions.sort[0].desc)
                    args.orderby += " desc";
            }

            args.skip = loadOptions.skip || 0;
            args.take = loadOptions.take || 12;

            $.ajax({
                url: "/Home/uretimyeriDropDown",
                dataType: "json",
                data: args,
                success: function (result) {                   
                    deferred.resolve(result.items, { totalCount: result.total_count });
                },
                error: function () {
                    deferred.reject("Data Loading Error");
                },
                timeout: 5000
            });

            return deferred.promise();
        }
    });
    
    var dataGrid1= $("#gridContainer").dxDataGrid({
        dataSource: {
            store: orders,
            key:"id"
        },
        remoteOperations: {
            sorting: true,
            paging: true
        },
        onRowUpdating: function (options) {
            options.newData = $.extend({}, options.oldData, options.newData);
        },
        selection: {
            mode: 'single'
        },
        paging: {
            pageSize: 12
        },
        pager: {
            showPageSizeSelector: true,
            allowedPageSizes: [8, 12, 20]
        },
        editing: {
            mode: "row",
            allowUpdating: true,
            allowDeleting: true,
            allowAdding: true
        },
        columnsAutoWidth: true,
        filterRow: {
            visible: true,
            applyFilter: "auto"
        },
        searchPanel: {
            visible: true,
            width: 240,
            placeholder: "Search..."
        },
        headerFilter: {
            visible: true
        },        
        columns: [{
            dataField: "nakliyeBelgesi",
            alignment: "right",            
            editorOptions: {                
                showClearButton: true
            }
        }, {
            dataField: "planlamaTarihi",
            alignment: "right",
            dataType: "date",
            width: 120,
            calculateFilterExpression: function (value, selectedFilterOperations, target) {
                if (target === "headerFilter" && value === "weekends") {
                    return [[getOrderDay, "=", 0], "or", [getOrderDay, "=", 6]];
                }
                return this.defaultCalculateFilterExpression.apply(this, arguments);
            },
            headerFilter: {
                dataSource: function (data) {
                    data.dataSource.postProcess = function (results) {
                        results.push({
                            text: "Weekends",
                            value: "weekends"
                        });
                        return results;
                    };
                }
            }
        },    
            {
                dataField: "yuklemeYeriId",
                caption: "Üretim Yeri",
                alignment: "right",
                lookup: {
                    dataSource: uretimyeri,
                    displayExpr: "uretimYeriAdi",
                    valueExpr: "yuklemeYeriId"
                },
                editorOptions: {
                    showClearButton: false
                }
            },
        {
            dataField: "nakliyeciAdi",
            caption:"Nakliyeci",
            alignment: "right",
            format: "currency",
            editorOptions: {       
                showClearButton: true
            }
            },
            {
                dataField: "musteriler",
                caption: "Müşteriler",
                alignment: "right",                              
                editorOptions: {
                    showClearButton: true
                }
            },
   
        {
            dataField: "aciklamaSM",
            alignment: "right",     
            editorOptions: {      
                showClearButton: true
            }
        },
        {
            dataField: "toplamTonaj",
            alignment: "right",    
            editorOptions: {             
                showClearButton: true
            }
        },
        {
            dataField: "aracTipiId",
            caption:"Araç Tipi",
            alignment: "right", 
            lookup: {
                dataSource: aracTipi,
                displayExpr: "aracTipiId",
                valueExpr: "aracTipiId"
            },
            editorOptions: {    
                showClearButton: false
            }
            },
            {
                dataField: "yuklemeNoktasiId",
                caption: "Yükleme Noktası",
                alignment: "right",
                lookup: {
                    dataSource: yuklemeNoktasi,
                    displayExpr: "ynAdi",
                    valueExpr: "yuklemeNoktasiId"
                },
                editorOptions: {
                    showClearButton: false
                }
            }],
            onEditingStart: function (e) {
                logEvent("EditingStart");
            },
        onInitNewRow: function (e) {
            logEvent("InitNewRow");
        },
        onRowInserting: function (e) {
            logEvent("RowInserting");
        },
        onRowInserted: function (e) {
            logEvent("RowInserted");
        },
        onRowUpdating: function (e) {
            logEvent("RowUpdating");
        },
        onRowUpdated: function (e) {
            logEvent("RowUpdated");
        },
        onRowRemoving: function (e) {
            logEvent("RowRemoving");
        },
        onRowRemoved: function (e) {
            logEvent("RowRemoved");
        },
        onSelectionChanged: function (selectedItems) {
            var id = selectedItems.selectedRowsData[0]["id"];
            var currentdate = new Date();
            var datetime = currentdate.getDate() + "/"
                + (currentdate.getMonth() + 1) + "/"
                + currentdate.getFullYear() + " "
                + currentdate.getHours() + ":"
                + currentdate.getMinutes() + ":"
                + currentdate.getSeconds();
            selected_row_id = id;
            console.log(datetime);
            console.log(selected_row_id);
        }
       
    }).dxDataGrid('instance');
    $(function () {
       

        var applyFilterTypes = [{
            key: "auto",
            name: "Immediately"
        }, {
            key: "onClick",
            name: "On Button Click"
        }];

        var applyFilterModeEditor = $("#useFilterApplyButton").dxSelectBox({
            items: applyFilterTypes,
            value: applyFilterTypes[0].key,
            valueExpr: "key",
            displayExpr: "name",
            onValueChanged: function (data) {
                dataGrid.option("filterRow.applyFilter", data.value);
            }
        }).dxSelectBox("instance");

        $("#filterRow").dxCheckBox({
            text: "Filter Row",
            value: true,
            onValueChanged: function (data) {
                dataGrid.clearFilter();
                dataGrid.option("filterRow.visible", data.value);
                applyFilterModeEditor.option("disabled", !data.value);
            }
        });

        $("#headerFilter").dxCheckBox({
            text: "Header Filter",
            value: true,
            onValueChanged: function (data) {
                dataGrid.clearFilter();
                dataGrid.option("headerFilter.visible", data.value);
            }
        });

        function getOrderDay(rowData) {
            return (new Date(rowData.OrderDate)).getDay();
        }
    });
    $('#onayla').click(function () {
        $.ajax({
            url: "Home/yuklemeOnayla",
            contentType: "application/json; charset=utf-8",
            method: "POST",
            data: JSON.stringify(selected_row_id),
            dataType: "json",
            success: function (result) {
                dataGrid1.refresh();                                
            },
            timeout: 5000
        });
        dataGrid2.refresh();
    });
 //Function For Grid2
    var orders2 = new DevExpress.data.CustomStore({
        load: function (loadOptions) {
            var deferred = $.Deferred(),
                args = {};

            if (loadOptions.sort) {
                args.orderby = loadOptions.sort[0].selector;
                if (loadOptions.sort[0].desc)
                    args.orderby += " desc";
            }

            args.skip = loadOptions.skip || 0;
            args.take = loadOptions.take || 12;
            $.ajax({
                url: "/Home/getGrid2Datas",
                dataType: "json",
                data: args,
                success: function (result) {

                    deferred.resolve(result.items, { totalCount: result.total_count });
                },
                error: function () {
                    deferred.reject("Data Loading Error");
                },
                timeout: 5000
            });
            return deferred.promise();
        }
    });
    var aracTipi = new DevExpress.data.CustomStore({
        load: function (loadOptions) {
            var deferred = $.Deferred(),
                args = {};

            if (loadOptions.sort) {
                args.orderby = loadOptions.sort[0].selector;
                if (loadOptions.sort[0].desc)
                    args.orderby += " desc";
            }

            args.skip = loadOptions.skip || 0;
            args.take = loadOptions.take || 12;

            $.ajax({
                url: "/Home/aracTipiDropDown",
                dataType: "json",
                data: args,
                success: function (result) {                 
                    deferred.resolve(result.items, { totalCount: result.total_count });
                },
                error: function () {
                    deferred.reject("Data Loading Error");
                },
                timeout: 5000
            });

            return deferred.promise();
        }
    });
    var yuklemeNoktasi = new DevExpress.data.CustomStore({
        load: function (loadOptions) {
            var deferred = $.Deferred(),
                args = {};

            if (loadOptions.sort) {
                args.orderby = loadOptions.sort[0].selector;
                if (loadOptions.sort[0].desc)
                    args.orderby += " desc";
            }

            args.skip = loadOptions.skip || 0;
            args.take = loadOptions.take || 12;

            $.ajax({
                url: "/Home/yuklemeNoktasiDropDown",
                dataType: "json",
                data: args,
                success: function (result) {
                    deferred.resolve(result.items, { totalCount: result.total_count });
                },
                error: function () {
                    deferred.reject("Data Loading Error");
                },
                timeout: 5000
            });

            return deferred.promise();
        }
    });
    var uretimyeri = new DevExpress.data.CustomStore({
        load: function (loadOptions) {
            var deferred = $.Deferred(),
                args = {};

            if (loadOptions.sort) {
                args.orderby = loadOptions.sort[0].selector;
                if (loadOptions.sort[0].desc)
                    args.orderby += " desc";
            }

            args.skip = loadOptions.skip || 0;
            args.take = loadOptions.take || 12;

            $.ajax({
                url: "/Home/uretimyeriDropDown",
                dataType: "json",
                data: args,
                success: function (result) {
                    deferred.resolve(result.items, { totalCount: result.total_count });
                },
                error: function () {
                    deferred.reject("Data Loading Error");
                },
                timeout: 5000
            });

            return deferred.promise();
        }
    });
    var dataGrid2 = $("#gridContainer2").dxDataGrid({
        dataSource: {
            store: orders2
        },
        remoteOperations: {
            sorting: true,
            paging: true
        },
        paging: {
            pageSize: 12
        },
        pager: {
            showPageSizeSelector: true,
            allowedPageSizes: [8, 12, 20]
        },
        editing: {
            mode: "row",
            allowUpdating: true,
            allowDeleting: true,
            allowAdding: true
        },
        columnsAutoWidth: true,
        filterRow: {
            visible: true,
            applyFilter: "auto"
        },
        searchPanel: {
            visible: true,
            width: 240,
            placeholder: "Search..."
        },
        headerFilter: {
            visible: true
        },
        columns: [{
            dataField: "nakliyeBelgesi",
            alignment: "right",
            editorOptions: {
                showClearButton: true
            }
        }, {
            dataField: "planlamaTarihi",
            alignment: "right",
            dataType: "date",
            width: 120,
            calculateFilterExpression: function (value, selectedFilterOperations, target) {
                if (target === "headerFilter" && value === "weekends") {
                    return [[getOrderDay, "=", 0], "or", [getOrderDay, "=", 6]];
                }
                return this.defaultCalculateFilterExpression.apply(this, arguments);
            },
            headerFilter: {
                dataSource: function (data) {
                    data.dataSource.postProcess = function (results) {
                        results.push({
                            text: "Weekends",
                            value: "weekends"
                        });
                        return results;
                    };
                }
            }
        },
        {
            dataField: "yuklemeYeriId",
            caption: "Üretim Yeri",
            alignment: "right",
            lookup: {
                dataSource: uretimyeri,
                displayExpr: "uretimYeriAdi",
                valueExpr: "yuklemeYeriId"
            },
            editorOptions: {
                showClearButton: false
            }
        },
        {
            dataField: "nakliyeciAdi",
            caption: "Nakliyeci",
            alignment: "right",
            format: "currency",
            editorOptions: {
                showClearButton: true
            }
        },
        {
            dataField: "musteriler",
            caption: "Müşteriler",
            alignment: "right",
            editorOptions: {
                showClearButton: true
            }
        },
        {
            dataField: "aciklamaSM",
            alignment: "right",
            editorOptions: {
                showClearButton: true
            }
        },
        {
            dataField: "aciklamaNK",
            alignment: "right",
            editorOptions: {
                showClearButton: true
            }
        },
        {
            dataField: "toplamTonaj",
            alignment: "right",
            editorOptions: {
                showClearButton: true
            }
        },
        {
            dataField: "aracTipiId",
            caption: "Araç Tipi",
            alignment: "right",
            lookup: {
                dataSource: aracTipi,
                displayExpr: "aracTipiId",
                valueExpr: "aracTipiId"
            },
            editorOptions: {
                showClearButton: false
            }
        },
        {
            dataField: "yuklemeNoktasiId",
            caption: "Yükleme Noktası",
            alignment: "right",
            lookup: {
                dataSource: yuklemeNoktasi,
                displayExpr: "ynAdi",
                valueExpr: "yuklemeNoktasiId"
            },
            editorOptions: {
                showClearButton: false
            }
        },
        {
            dataField: "onayZamani",
            alignment: "right",
            dataType: "datetime",
            width: 120,
            calculateFilterExpression: function (value, selectedFilterOperations, target) {
                if (target === "headerFilter" && value === "weekends") {
                    return [[getOrderDay, "=", 0], "or", [getOrderDay, "=", 6]];
                }
                return this.defaultCalculateFilterExpression.apply(this, arguments);
            },
            headerFilter: {
                dataSource: function (data) {
                    data.dataSource.postProcess = function (results) {
                        results.push({
                            text: "Weekends",
                            value: "weekends"
                        });
                        return results;
                    };
                }
            }
        }]

    }).dxDataGrid('instance');
    $(function () {


        var applyFilterTypes = [{
            key: "auto",
            name: "Immediately"
        }, {
            key: "onClick",
            name: "On Button Click"
        }];

        var applyFilterModeEditor = $("#useFilterApplyButton").dxSelectBox({
            items: applyFilterTypes,
            value: applyFilterTypes[0].key,
            valueExpr: "key",
            displayExpr: "name",
            onValueChanged: function (data) {
                dataGrid.option("filterRow.applyFilter", data.value);
            }
        }).dxSelectBox("instance");

        $("#filterRow").dxCheckBox({
            text: "Filter Row",
            value: true,
            onValueChanged: function (data) {
                dataGrid.clearFilter();
                dataGrid.option("filterRow.visible", data.value);
                applyFilterModeEditor.option("disabled", !data.value);
            }
        });

        $("#headerFilter").dxCheckBox({
            text: "Header Filter",
            value: true,
            onValueChanged: function (data) {
                dataGrid.clearFilter();
                dataGrid.option("headerFilter.visible", data.value);
            }
        });

        function getOrderDay(rowData) {
            return (new Date(rowData.OrderDate)).getDay();
        }
    });



       

});


 

function arsTabs(evt, tabName) {
    var i, tabcontent, tablinks, dataGrid;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");       
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}


    