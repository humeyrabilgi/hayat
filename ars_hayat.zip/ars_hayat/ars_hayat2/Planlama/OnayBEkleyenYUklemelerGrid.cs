﻿using ars_hayat2.Database;
using ars_hayat2.DTO;
using ars_hayat2.Planlama;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ars_hayat2.Planlama
{
    public class OnayBekleyenYuklemelerGrid
    {

        public List<OnayBekleyenYuklemelerDTO> grid()
        {           
            OnayBekleyenYuklemelerDTO oby = null;
            DatabaseConnection instance = new DatabaseConnection();
            DataTable dt = instance.db();
            List<OnayBekleyenYuklemelerDTO> onayBekleyenYuklemelerList = new List<OnayBekleyenYuklemelerDTO>();
            foreach (DataRow row in dt.Rows)
            {

                oby = new OnayBekleyenYuklemelerDTO();
                int.TryParse(row["NakliyeBelgesi"].ToString(), out int nb);
                oby.NakliyeBelgesi = nb;
                DateTime.TryParse(row["PlanlamaTarihi"].ToString(), out DateTime dtime);
                oby.PlanlamaTarihi = dtime;
                oby.UretimYeri = row["UretimYeri"].ToString();
                oby.Musteriler = row["Musteriler"].ToString();
                oby.SevkYeri = row["SevkYeri"].ToString();
                oby.AciklamaSM = row["AciklamaSM"].ToString();
                int.TryParse(row["ToplamTonaj"].ToString(), out int tt);
                oby.ToplamTonaj = tt;
                oby.AracTipi = row["AracTipi"].ToString();
                int.TryParse(row["YuklemeYeriId"].ToString(), out int YYI);
                oby.YuklemeYeriId = YYI;
                int.TryParse(row["NakliyeciId"].ToString(), out int NI);
                oby.NakliyeciId = NI;
                int.TryParse(row["YuklemeNoktasiId"].ToString(), out int YNI);
                oby.YuklemeNoktasiId = YNI;
                onayBekleyenYuklemelerList.Add(oby);
            }
            return onayBekleyenYuklemelerList;


        }
    }
}
