﻿using ars_hayat.Database;
using ars_hayat.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ars_hayat.Planlama
{
    public class OnayBekleyenYuklemelerGrid
    {
        public List<OnayBekleyenYuklemelerDTO> grid()
        {
            OnayBekleyenYuklemelerDTO oby = null;
            DatabaseConnection instance = new DatabaseConnection();
            DataTable dt = instance.db();
            List<OnayBekleyenYuklemelerDTO> onayBekleyenYuklemelerList = new List<OnayBekleyenYuklemelerDTO>();
            foreach (DataRow row in dt.Rows)
            {
                oby = new OnayBekleyenYuklemelerDTO();
                int.TryParse(row["NakliyeBelgesi"].ToString(), out int nb);
                oby.NakliyeBelgesi = nb;
                DateTime.TryParse(row["PlanlamaTarihi"].ToString(), out DateTime dtime);
                oby.PlanlamaTarihi = dtime;
                //oby.UretimYeri = row["UretimYeri"].ToString();          
                //oby.SevkYeri = row["sevkYeri"].ToString();
                oby.AciklamaSM = row["AciklamaSM"].ToString();
                float.TryParse(row["ToplamTonaj"].ToString(), out float tt);
                oby.ToplamTonaj = tt;
                oby.AracTipiId = row["AracTipiId"].ToString();
                int.TryParse(row["YuklemeYeriId"].ToString(), out int YYI);
                oby.YuklemeYeriId = YYI;
                oby.NakliyeciAdi = row["NakliyeciAdi"].ToString();
                int.TryParse(row["YuklemeNoktasiId"].ToString(), out int YNI);
                oby.YuklemeNoktasiId = YNI;
                //int.TryParse(row["NakliyeciId"].ToString(), out int NI);
                //oby.NakliyeciId = NI;
                oby.Musteriler = row["Musteriler"].ToString();
                onayBekleyenYuklemelerList.Add(oby);
                int.TryParse(row["Id"].ToString(), out int Id);
                oby.Id = Id;
            }
            return onayBekleyenYuklemelerList;
        }

        public List<OnayBekleyenYuklemelerDTO> aracTipi()
        {
            OnayBekleyenYuklemelerDTO obyatt = null;
            DatabaseConnection instance = new DatabaseConnection();
            DataTable att = instance.aracTipidb();
            List<OnayBekleyenYuklemelerDTO> onayBekleyenYuklemelerListatt = new List<OnayBekleyenYuklemelerDTO>();
            foreach (DataRow row in att.Rows)
            {
                obyatt = new OnayBekleyenYuklemelerDTO();
                obyatt.AracTipiId = row["AracTipiId"].ToString();
                onayBekleyenYuklemelerListatt.Add(obyatt);
            }
            return onayBekleyenYuklemelerListatt;
        }
        public List<OnayBekleyenYuklemelerDTO> yuklemeNoktasi()
        {
            OnayBekleyenYuklemelerDTO obyynt = null;
            DatabaseConnection instance = new DatabaseConnection();
            DataTable ynt = instance.yuklemeNokyasidb();
            List<OnayBekleyenYuklemelerDTO> onayBekleyenYuklemelerListynt = new List<OnayBekleyenYuklemelerDTO>();
            foreach (DataRow row in ynt.Rows)
            {
                obyynt = new OnayBekleyenYuklemelerDTO();
                int.TryParse(row["Id"].ToString(), out int Id);
                obyynt.Id = Id;
                obyynt.YNAdi = row["YNadi"].ToString();
                int.TryParse(row["YuklemeNoktasiId"].ToString(), out int ynid);
                obyynt.YuklemeNoktasiId = ynid;
                onayBekleyenYuklemelerListynt.Add(obyynt);
            }
            return onayBekleyenYuklemelerListynt;
        }
        public List<OnayBekleyenYuklemelerDTO> uretimYeri()
        {
            OnayBekleyenYuklemelerDTO obyuyt = null;
            DatabaseConnection instance = new DatabaseConnection();
            DataTable uyt = instance.uretimyeridb();
            List<OnayBekleyenYuklemelerDTO> onayBekleyenYuklemelerListuyt = new List<OnayBekleyenYuklemelerDTO>();
            foreach (DataRow row in uyt.Rows)
            {
                obyuyt = new OnayBekleyenYuklemelerDTO();
                int.TryParse(row["UretimyeriKodu"].ToString(), out int uyk);
                obyuyt.UretimyeriKodu = uyk;
                obyuyt.UretimYeriAdi = row["UretimYeriAdi"].ToString();                
                int.TryParse(row["YuklemeYeriId"].ToString(), out int yYId);
                obyuyt.YuklemeYeriId = yYId;
                onayBekleyenYuklemelerListuyt.Add(obyuyt);
            }
            return onayBekleyenYuklemelerListuyt;
        }
        public void yuklemeOnayla(int id)
        {
            DatabaseConnection instance = new DatabaseConnection();
            instance.onayla(id);

        }
        public void getUpdate(OnayBekleyenYuklemelerDTO obj)
        {
            DatabaseConnection instance = new DatabaseConnection();
            instance.updateTable(obj);
        }
        public void getRemove(OnayBekleyenYuklemelerDTO obj)
        {
            DatabaseConnection instance = new DatabaseConnection();
            instance.removeRow(obj);
        }
        public void getInsert(OnayBekleyenYuklemelerDTO obj)
        {
            DatabaseConnection instance = new DatabaseConnection();
            instance.insertRow(obj);
        }
    }
}
