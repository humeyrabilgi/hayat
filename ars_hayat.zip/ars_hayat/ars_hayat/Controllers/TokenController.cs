﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using ars_hayat.DTO;
using ars_hayat.Planlama;
using ars_hayat.Database;
using System.Data.SqlClient;
using System.Data;

namespace ars_hayat.Controllers
{
    [Route("token")]
    [AllowAnonymous()]
    public class TokenController : Controller
    {
              


        [Route("new")]
        [HttpPost]
        public IActionResult GetToken([FromBody]DTO.UserInfo user)
        {
            Console.Write("aaassss");
            Console.WriteLine("User name:{0}", user.Username);
            Console.WriteLine("Password:{0}", user.Password);

            if (IsValidUserAndPassword(user.Username, user.Password))
                return new ObjectResult(GenerateToken(user.Username));
            else {
                return Unauthorized();
            }
            
        }

        private string GenerateToken(string userName)
        {
            
            var someClaims = new Claim[]{
                new Claim(JwtRegisteredClaimNames.UniqueName,userName),
                new Claim(JwtRegisteredClaimNames.Email,"heimdall@mail.com"),
                new Claim(JwtRegisteredClaimNames.NameId,Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.Role,"")
            };
            Console.Write("vzaaaxx");

            SecurityKey securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("uzun ince bir yoldayım şarkısını buradan tüm sevdiklerime hediye etmek istiyorum mümkün müdür acaba?"));
            var token = new JwtSecurityToken(
                issuer: "west-world.fabrikam.com",
                audience: "heimdall.fabrikam.com",
                claims: someClaims,
                expires: DateTime.Now.AddMonths(6),
                signingCredentials: new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256)
            );
            Console.Write("buraya bakkkk");
            Console.Write(new JwtSecurityTokenHandler().WriteToken(token));

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private bool IsValidUserAndPassword(string userName, string password)
        {
            Console.Write("d22222222*****jdjdjd");
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand(@"SELECT u.[Username], u.[Password] ,u.[UserType]
                FROM [tblUser] u   
				WHERE u.[Username] = @p1 AND u.[Password] = @p2", conn);
                command.Parameters.Add(new SqlParameter("@p1", userName));
                command.Parameters.Add(new SqlParameter("@p2", password));

                SqlDataReader reader = command.ExecuteReader();
                DataTable result = new DataTable();
                result.Load(reader);
                reader.Close();
                if (result.Rows.Count > 0)
                {
                    if (string.Compare(result.Rows[0]["Password"].ToString(), password,false) == 0)
                    {
                        return true;
                    }
                }

                conn.Close();
                return false;
            }
            

            //Sürekli true dönüyor. Normalde bir Identity mekanizması ile entegre etmemiz lazım.
            
        }
    }
}

//if (string.Compare(result.Rows[0]["Password"].ToString(), password,false) > 0)
//                    {
//                        return true;
//                    }