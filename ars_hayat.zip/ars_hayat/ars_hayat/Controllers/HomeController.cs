﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ars_hayat.Models;
using ars_hayat.Planlama;
using ars_hayat.DTO;

namespace ars_hayat.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        //For Grid1
        public IActionResult getGridDatas()
        {
            OnayBekleyenYuklemelerGrid grid = new OnayBekleyenYuklemelerGrid();
            var data = grid.grid();
            return Json(new { items = data, total_count = data.Count });          
        }
        public IActionResult aracTipiDropDown()
        {
            OnayBekleyenYuklemelerGrid aracTipi = new OnayBekleyenYuklemelerGrid();
            var data = aracTipi.aracTipi();
            return Json(new { items = data, total_count = data.Count });
        }
        public IActionResult yuklemeNoktasiDropDown()
        {
            OnayBekleyenYuklemelerGrid yuklemeNoktasi = new OnayBekleyenYuklemelerGrid();
            var data = yuklemeNoktasi.yuklemeNoktasi();
            return Json(new { items = data, total_count = data.Count });
        }
        public IActionResult uretimyeriDropDown()
        {
            OnayBekleyenYuklemelerGrid uretimyeri = new OnayBekleyenYuklemelerGrid();
            var data = uretimyeri.uretimYeri();
            return Json(new { items = data, total_count = data.Count });
        }

        [HttpPost]
        public IActionResult yuklemeOnayla([FromBody] int selected_row_id)
        {
            OnayBekleyenYuklemelerGrid onayla = new OnayBekleyenYuklemelerGrid();
            onayla.yuklemeOnayla(selected_row_id);
            return Json(true);
        }
        //For Grid2
        public IActionResult getGrid2Datas()
        {
            OnaylanmisYuklemelerGrid grid2 = new OnaylanmisYuklemelerGrid();
            var data = grid2.grid2();
            return Json(new { items = data, total_count = data.Count });
        }
        public IActionResult aracTipiDropDown2()
        {
            OnaylanmisYuklemelerGrid aracTipi2 = new OnaylanmisYuklemelerGrid();
            var data = aracTipi2.aracTipi2();            
            return Json(new { items = data, total_count = data.Count });
        }
        public IActionResult yuklemeNoktasiDropDown2()
        {
            OnaylanmisYuklemelerGrid yuklemeNoktasi2 = new OnaylanmisYuklemelerGrid();
            var data = yuklemeNoktasi2.yuklemeNoktasi2();
            return Json(new { items = data, total_count = data.Count });
        }
        public IActionResult uretimyeriDropDown2()
        {
            OnaylanmisYuklemelerGrid uretimyeri2 = new OnaylanmisYuklemelerGrid();
            var data = uretimyeri2.uretimyeri2();
            return Json(new { items = data, total_count = data.Count });
        }
        //Updates
        public IActionResult Update1([FromBody]OnayBekleyenYuklemelerDTO obj)
        {
            OnayBekleyenYuklemelerGrid update = new OnayBekleyenYuklemelerGrid();
            update.getUpdate(obj);
            return Json(true);
        }
        public IActionResult Remove([FromBody]OnayBekleyenYuklemelerDTO obj)
        {
            OnayBekleyenYuklemelerGrid remove = new OnayBekleyenYuklemelerGrid();
            remove.getRemove(obj);
            return Json(true);
        }
        public IActionResult Insert([FromBody]OnayBekleyenYuklemelerDTO obj)
        {
            OnayBekleyenYuklemelerGrid insert = new OnayBekleyenYuklemelerGrid();
            insert.getInsert(obj);
            return Json(true);
        }
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
       

       
    }
}
