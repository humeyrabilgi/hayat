﻿using ars_hayat.DTO;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ars_hayat.Database
{
    public class DatabaseConnection
    {
        public DataTable db()
        {

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand(@"SELECT y.[Id], n.[NakliyeciAdi],Email,y.[NakliyeBelgesi], y.[PlanlamaTarihi], y.[YuklemeYeriId],y.[YuklemeNoktasiId],
                    y.[AciklamaSM],y.[AracTipiId],round( Cast(y.ToplamTonaj as Float),0) as ToplamTonaj, y.[YuklemeStatus], y.[KantarOnKayitDurumu],
             (SELECT [dbo].[fn_Musteriler] (
              y.[NakliyeBelgesi]) ) as Musteriler,
               (SELECT [dbo].[fn_TeslimatYerleri] (
              y.[NakliyeBelgesi]) ) as TYerleri
             FROM  [tblYuklemeEmirleri] y                  
                    INNER JOIN [tblNakliyeFirmalari] n ON  n.[FirmaKodu] =y.[NakliyeciId] WHERE (y.[YuklemeStatus] = 0   and y.GirisSaati is  null and y.CikisSaati is  null) 
                    ORDER BY y.[PlanlamaTarihi] desc", conn);
                command.Parameters.Add(new SqlParameter("0", 1));
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                conn.Close();
                return dt;
            }


        }
        public DataTable aracTipidb()
        {

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand(@"SELECT y.[AracTipiId], y.[NakliyeBelgesi]
                FROM  [tblYuklemeEmirleri] y
                ORDER BY y.[NakliyeBelgesi] asc", conn);
                command.Parameters.Add(new SqlParameter("0", 1));
                SqlDataReader reader = command.ExecuteReader();
                DataTable att = new DataTable();
                att.Load(reader);
                conn.Close();
                return att;
            }
        }
        public DataTable yuklemeNokyasidb()
        {

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand(@"SELECT y.[YNAdi], y.[Id], n.[YuklemeNoktasiId]
                FROM [tblYuklemeNoktalari] y                  
                INNER JOIN [tblYuklemeEmirleri] n ON  n.[YuklemeNoktasiId] =y.[Id] WHERE (y.Id is not  null) 
                ORDER BY y.[Id] asc", conn);
                command.Parameters.Add(new SqlParameter("0", 1));
                SqlDataReader reader = command.ExecuteReader();
                DataTable ynt = new DataTable();
                ynt.Load(reader);
                conn.Close();
                return ynt;
            }
        }
        public DataTable uretimyeridb()
        {

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand(@"SELECT y.[UretimYeriAdi], y.[UretimyeriKodu], n.[YuklemeYeriId]
                FROM [tblYuklemeYerleri] y
                INNER JOIN [tblYuklemeEmirleri] n  ON  n.[YuklemeYeriId] =y.[UretimyeriKodu]             
                WHERE (y.UretimyeriKodu is not  null) 
                ORDER BY y.[UretimyeriKodu] asc", conn);
                command.Parameters.Add(new SqlParameter("0", 1));
                SqlDataReader reader = command.ExecuteReader();
                DataTable uyt = new DataTable();
                uyt.Load(reader);
                conn.Close();
                return uyt;
            }
        }
        public DataTable onayla(int id)
        {

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand(@"UPDATE tblYuklemeEmirleri 
                                    SET OnayZamani=@OnayZamani,
                                        YuklemeStatus=1
                                    WHERE Id=@Id", conn);
                DateTime selected_row_date = DateTime.Now;
                command.Parameters.Add(new SqlParameter("0", 1));
                command.Parameters.AddWithValue("@Id", id);
                command.Parameters.AddWithValue("@OnayZamani", selected_row_date);
                SqlDataReader reader = command.ExecuteReader();
                DataTable ot = new DataTable();
                ot.Load(reader);
                command.ExecuteNonQuery();
                conn.Close();
                return ot;
            }
        }
        public DataTable db2()
        {

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand(@"SELECT n.[NakliyeciAdi],Email,       y.[NakliyeBelgesi],y.[Ihalede],  y.[PlanlamaTarihi], y.[YuklemeYeriId],
                    y.[YuklemeNoktasiId], y.[AciklamaSM],y.[AciklamaNK], y.[AracTipiId],round( Cast(y.ToplamTonaj as Float),0) as ToplamTonaj, 
                    y.[YuklemeStatus], y.[RezervasyonTarihi],  y.[AracId],y.[SoforId],y.[YuklemeRampaId],y.[OnayZamani],
             (SELECT [dbo].[fn_Musteriler] (
              y.[NakliyeBelgesi]) ) as Musteriler,
               (SELECT [dbo].[fn_TeslimatYerleri] (
              y.[NakliyeBelgesi]) ) as TYerleri
                     FROM  [tblYuklemeEmirleri] y INNER JOIN [tblNakliyeFirmalari] n ON  n.[FirmaKodu] =y.[NakliyeciId]                  
                    WHERE (y.[YuklemeStatus] = 1 and  y.GirisSaati is  null and y.CikisSaati is  null) ORDER BY y.[PlanlamaTarihi] desc", conn);
                command.Parameters.Add(new SqlParameter("0", 1));
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                conn.Close();
                return dt;
            }


        }
        public DataTable updateTable([FromBody]OnayBekleyenYuklemelerDTO obj )
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand(@"SET NakliyeBelgesi=@NakliyeBelgesi,
                                           PlanlamaTarihi=@PlanlamaTarihi,
                                           YuklemeYeriId=@YuklemeYeriId,
                                           UretimYeriAdi=@UretimYeriAdi,
                                           NakliyeciAdi=@NakliyeciAdi,
                                           Musteriler=@Musteriler,
                                           TeslimatYerleri=@TeslimatYerleri,
                                           AciklamaSM=@AciklamaSM,
                                           ToplamTonaj=@ToplamTonaj, 
                                           YuklemeNoktasiId=@YuklemeNoktasiId,
                                           AracTipiId=@AracTipiId,
                                           YNAdi=@YNAdi                                           
                                    WHERE Id=@Id", conn);               
                command.Parameters.Add(new SqlParameter("0", 1));
                command.Parameters.AddWithValue("@NakliyeBelgesi", obj.NakliyeBelgesi);
                command.Parameters.AddWithValue("@PlanlamaTarihi", obj.PlanlamaTarihi);
                command.Parameters.AddWithValue("@YuklemeYeriId", obj.YuklemeYeriId);
                command.Parameters.AddWithValue("@UretimYeriAdi", obj.UretimYeriAdi);
                command.Parameters.AddWithValue("@NakliyeciAdi", obj.NakliyeciAdi);
                command.Parameters.AddWithValue("@Musteriler", obj.Musteriler);
                command.Parameters.AddWithValue("@TeslimatYerleri", obj.TeslimatYerleri);
                command.Parameters.AddWithValue("@AciklamaSM", obj.AciklamaSM);
                command.Parameters.AddWithValue("@ToplamTonaj", obj.ToplamTonaj);
                command.Parameters.AddWithValue("@YuklemeNoktasiId", obj.YuklemeNoktasiId);
                command.Parameters.AddWithValue("@AracTipiId", obj.AracTipiId);
                command.Parameters.AddWithValue("@Id", obj.Id);
                SqlDataReader reader = command.ExecuteReader();
                DataTable upt = new DataTable();
                upt.Load(reader);
                command.ExecuteNonQuery();
                conn.Close();
                return upt;
            }
        }
        public DataTable removeRow([FromBody]OnayBekleyenYuklemelerDTO obj)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand(@"SET NakliyeBelgesi=@NakliyeBelgesi,
                                           PlanlamaTarihi=@PlanlamaTarihi,
                                           YuklemeYeriId=@YuklemeYeriId,
                                           UretimYeriAdi=@UretimYeriAdi,
                                           NakliyeciAdi=@NakliyeciAdi,
                                           Musteriler=@Musteriler,
                                           TeslimatYerleri=@TeslimatYerleri,
                                           AciklamaSM=@AciklamaSM,
                                           ToplamTonaj=@ToplamTonaj, 
                                           YuklemeNoktasiId=@YuklemeNoktasiId,
                                           AracTipiId=@AracTipiId,
                                           YNAdi=@YNAdi                                           
                                    WHERE Id=@Id", conn);                
                command.Parameters.Add(new SqlParameter("0", 1));
                command.Parameters.AddWithValue("@NakliyeBelgesi", obj.NakliyeBelgesi);
                command.Parameters.AddWithValue("@PlanlamaTarihi", obj.PlanlamaTarihi);
                command.Parameters.AddWithValue("@YuklemeYeriId", obj.YuklemeYeriId);
                command.Parameters.AddWithValue("@UretimYeriAdi", obj.UretimYeriAdi);
                command.Parameters.AddWithValue("@NakliyeciAdi", obj.NakliyeciAdi);
                command.Parameters.AddWithValue("@Musteriler", obj.Musteriler);
                command.Parameters.AddWithValue("@TeslimatYerleri", obj.TeslimatYerleri);
                command.Parameters.AddWithValue("@AciklamaSM", obj.AciklamaSM);
                command.Parameters.AddWithValue("@ToplamTonaj", obj.ToplamTonaj);
                command.Parameters.AddWithValue("@YuklemeNoktasiId", obj.YuklemeNoktasiId);
                command.Parameters.AddWithValue("@AracTipiId", obj.AracTipiId);
                command.Parameters.AddWithValue("@Id", obj.Id);
                SqlDataReader reader = command.ExecuteReader();
                DataTable rt = new DataTable();
                rt.Load(reader);
                command.ExecuteNonQuery();
                conn.Close();
                return rt;
            }
        }
        public DataTable insertRow([FromBody]OnayBekleyenYuklemelerDTO obj)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand(@"SET NakliyeBelgesi=@NakliyeBelgesi,
                                           PlanlamaTarihi=@PlanlamaTarihi,
                                           YuklemeYeriId=@YuklemeYeriId,
                                           UretimYeriAdi=@UretimYeriAdi,
                                           NakliyeciAdi=@NakliyeciAdi,
                                           Musteriler=@Musteriler,
                                           TeslimatYerleri=@TeslimatYerleri,
                                           AciklamaSM=@AciklamaSM,
                                           ToplamTonaj=@ToplamTonaj, 
                                           YuklemeNoktasiId=@YuklemeNoktasiId,
                                           AracTipiId=@AracTipiId,
                                           YNAdi=@YNAdi                                           
                                    WHERE Id=@Id", conn);
                command.Parameters.Add(new SqlParameter("0", 1));
                command.Parameters.AddWithValue("@NakliyeBelgesi", obj.NakliyeBelgesi);
                command.Parameters.AddWithValue("@PlanlamaTarihi", obj.PlanlamaTarihi);
                command.Parameters.AddWithValue("@YuklemeYeriId", obj.YuklemeYeriId);
                command.Parameters.AddWithValue("@UretimYeriAdi", obj.UretimYeriAdi);
                command.Parameters.AddWithValue("@NakliyeciAdi", obj.NakliyeciAdi);
                command.Parameters.AddWithValue("@Musteriler", obj.Musteriler);
                command.Parameters.AddWithValue("@TeslimatYerleri", obj.TeslimatYerleri);
                command.Parameters.AddWithValue("@AciklamaSM", obj.AciklamaSM);
                command.Parameters.AddWithValue("@ToplamTonaj", obj.ToplamTonaj);
                command.Parameters.AddWithValue("@YuklemeNoktasiId", obj.YuklemeNoktasiId);
                command.Parameters.AddWithValue("@AracTipiId", obj.AracTipiId);
                command.Parameters.AddWithValue("@Id", obj.Id);
                SqlDataReader reader = command.ExecuteReader();
                DataTable it = new DataTable();
                it.Load(reader);
                command.ExecuteNonQuery();
                conn.Close();
                return it;
            }
        }
       


    }
}
