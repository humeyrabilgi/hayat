﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ars_hayat2.Planlama;

namespace ars_hayat2.Database
{
    public class DatabaseConnection
    {
        public DataTable db()
        {

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ars_hayat;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
                conn.Open();
                SqlCommand command = new SqlCommand("SELECT * FROM  [dbo].[tblYuklemeEmirleri]", conn);
                command.Parameters.Add(new SqlParameter("0", 1));
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                conn.Close();
                return dt;
            }
           

        }        
    }
}
