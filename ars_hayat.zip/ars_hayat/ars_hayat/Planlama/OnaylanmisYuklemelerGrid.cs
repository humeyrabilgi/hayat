﻿using ars_hayat.Database;
using ars_hayat.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ars_hayat.Planlama
{
    public class OnaylanmisYuklemelerGrid
    {        
            public List<OnaylanmisYuklemelerDTO> grid2()
            {
            OnaylanmisYuklemelerDTO oy = null;
                DatabaseConnection instance = new DatabaseConnection();
                DataTable dt = instance.db2();
                List<OnaylanmisYuklemelerDTO> onaylanmisYuklemelerList = new List<OnaylanmisYuklemelerDTO>();
                foreach (DataRow row in dt.Rows)
                {
                    oy = new OnaylanmisYuklemelerDTO();
                    int.TryParse(row["NakliyeBelgesi"].ToString(), out int nb);
                    oy.NakliyeBelgesi = nb;
                    DateTime.TryParse(row["PlanlamaTarihi"].ToString(), out DateTime dtime);
                    oy.PlanlamaTarihi = dtime;                  
                    oy.AciklamaSM = row["AciklamaSM"].ToString();
                    float.TryParse(row["ToplamTonaj"].ToString(), out float tt);
                    oy.ToplamTonaj = tt;
                    oy.AracTipiId = row["AracTipiId"].ToString();
                    int.TryParse(row["YuklemeYeriId"].ToString(), out int YYI);
                    oy.YuklemeYeriId = YYI;
                    oy.NakliyeciAdi = row["NakliyeciAdi"].ToString();
                    int.TryParse(row["YuklemeNoktasiId"].ToString(), out int YNI);
                    oy.YuklemeNoktasiId = YNI;               
                    oy.Musteriler = row["Musteriler"].ToString();
                    onaylanmisYuklemelerList.Add(oy);
                    oy.AciklamaNK = row["AciklamaNK"].ToString();
                    DateTime.TryParse(row["OnayZamani"].ToString(), out DateTime oZamani);
                    oy.OnayZamani = oZamani;

            }
                return onaylanmisYuklemelerList;
            }

            public List<OnaylanmisYuklemelerDTO> aracTipi2()
            {
            OnaylanmisYuklemelerDTO oyatt = null;
                DatabaseConnection instance = new DatabaseConnection();
                DataTable att = instance.aracTipidb();
                List<OnaylanmisYuklemelerDTO> onaylanmisYuklemelerListatt = new List<OnaylanmisYuklemelerDTO>();
                foreach (DataRow row in att.Rows)
                {
                    oyatt = new OnaylanmisYuklemelerDTO();
                    oyatt.AracTipiId = row["AracTipiId"].ToString();
                    onaylanmisYuklemelerListatt.Add(oyatt);
                }
                return onaylanmisYuklemelerListatt;
            }
            public List<OnaylanmisYuklemelerDTO> yuklemeNoktasi2()
            {
            OnaylanmisYuklemelerDTO oyynt = null;
                DatabaseConnection instance = new DatabaseConnection();
                DataTable ynt = instance.yuklemeNokyasidb();
                List<OnaylanmisYuklemelerDTO> onaylanmisYuklemelerListynt = new List<OnaylanmisYuklemelerDTO>();
                foreach (DataRow row in ynt.Rows)
                {
                    oyynt = new OnaylanmisYuklemelerDTO();
                    int.TryParse(row["Id"].ToString(), out int Id);
                    oyynt.Id = Id;
                    oyynt.YNAdi = row["YNadi"].ToString();
                    int.TryParse(row["YuklemeNoktasiId"].ToString(), out int ynid);
                    oyynt.YuklemeNoktasiId = ynid;
                    onaylanmisYuklemelerListynt.Add(oyynt);
                }
                return onaylanmisYuklemelerListynt;
            }
            public List<OnaylanmisYuklemelerDTO> uretimyeri2()
            {
            OnaylanmisYuklemelerDTO oyuyt = null;
                DatabaseConnection instance = new DatabaseConnection();
                DataTable uyt = instance.uretimyeridb();
                List<OnaylanmisYuklemelerDTO> onaylanmisYuklemelerListuyt = new List<OnaylanmisYuklemelerDTO>();
                foreach (DataRow row in uyt.Rows)
                {
                    oyuyt = new OnaylanmisYuklemelerDTO();
                    int.TryParse(row["UretimyeriKodu"].ToString(), out int uyk);
                    oyuyt.UretimyeriKodu = uyk;
                    oyuyt.UretimYeriAdi = row["UretimYeriAdi"].ToString();
                    onaylanmisYuklemelerListuyt.Add(oyuyt);
                    int.TryParse(row["YuklemeYeriId"].ToString(), out int yYId);
                    oyuyt.YuklemeYeriId = yYId;
                }
                return onaylanmisYuklemelerListuyt;
            }
  

    }
}
